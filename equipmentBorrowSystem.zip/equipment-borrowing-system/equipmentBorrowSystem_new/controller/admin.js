const models = require("../model/index");
const { param } = require("../routes/user");
const sso = require("./ssoUtil.js");
const util = require("./util.js");
const { adminModel } = models;
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'; // 暂时解决证书过期问题

exports.tokenChecker = async (accesstoken) => {
    let flag = 1;
    let result = await sso.getUserInformation(accesstoken).then().catch(function (err) {
        flag = 0;
        return {
            errorCode: 401,  //token出错，401：请求要求用户的身份认证
            errorMsg: err,
            payload: {}
        };
    }
    );
    if(flag) {
        return {
            errorCode: 200,
            errorMsg: "accesstoken正确",
            payload: result
        };
    } else {
        return result;
    }
}

exports.putEquipmentAdd = async (body, params) => {
    let ret;
    let isCamera = body.isCamera;
    let base64 = body.photoData;
    let equipmentName = body.equipmentName;
    //console.log(base64);
    //先传设备属性,返回id：
    let modelResult1 = await models.adminModel.putEquipmentAdd1(isCamera, equipmentName);

    if(!modelResult1) {
        ret = {
            errorCode: 400,
            errorMsg: "添加设备的属性及状态失败",
            payload: {}
        };
        return ret;
    }

    let path = util.savePhoto(base64, modelResult1);
    //console.log("path");

    let modelResult = await models.adminModel.putEquipmentAdd(modelResult1, path);
    
    if (modelResult) {
        ret = {
            errorCode: 200,
            errorMsg: "成功添加设备",
            payload: {}
        };
    } else {
        ret = {
            errorCode: 400,
            errorMsg: "上传照片错误，添加失败",
            payload: {}
        };
    }
    return ret;
};

exports.deleteEquipmentDelete = async (body, params) => {
    let ret;
    let equipmentID = params.equipmentID;

    let isBorrowed = await models.adminModel.isEquipmentBorrowed(equipmentID);
    if (isBorrowed == 1) {
        ret = {
            errorCode: 600,
            errorMsg: "该设备未归还，请先归还再删除",
            payload: {}
        };
        return ret;
    }
    else if (isBorrowed == 2) {
        ret = {
            errorCode: 800,
            errorMsg: "查询设备状态失败",
            payload: {}
        };
        return ret;
    }

    let modelResult = await models.adminModel.deleteEquipmentDelete(equipmentID);
    if (modelResult) {
        ret = {
            errorCode: 200,
            errorMsg: "成功删除设备",
            payload: {}
        };
    } else {
        ret = {
            errorCode: 400,
            errorMsg: "删除设备失败",
            payload: {}
        };
    }
    return ret;
};

exports.isAdmin = async (stuID) => {
    let result = await adminModel.isAdmin(stuID);
    return result;
}

exports.getEquipmentOnLoan = async (params) => {
    let ret;
    let size = params.size;
    let page = params.page;
    let data =[];
    let modelResult = await adminModel.getEquipmentOnLoan();

    if (modelResult) {
        let totalNum = modelResult.totalNum;
        let equipmentRet = modelResult.data;
        //console.log(totalNum,equipmentRet);
        let start = ( page - 1) * size;
        let end = Math.min(start + parseInt(size), totalNum);
        //console.log(start,end,start + size);
        for (let i = start; i < end; i++){
            data.push(equipmentRet[i]);
        }
        if(!data){
                ret = {
                errorCode: 402,
                errorMsg: "获取借出设备信息page参数出错",
                payload: {}
            };
        } else {
            ret = {
                errorCode: 200,
                errorMsg: "成功返回设备信息",
                payload: {
                    totalNum: totalNum,
                    data: data,
                }
            };
        }   
    } else {
        ret = {
            errorCode: 400,
            errorMsg: "数据库错误",
            payload: {}
        }
    }
    return ret;
}

exports.getEquipmentOnLoanMsg = async (params) => {
    let ret;
    let equipmentID = params.equipmentID;
    let onLoan = await adminModel.getEquipmentState(equipmentID);

    if (onLoan == null) {
        ret = {
            errorCode: 400,
            errorMsg: "数据库错误",
            payload: {}
        }
    } else if (onLoan == 0) {
        ret = {
            errorCode: 402,
            errorMsg: "当前设备未借出",
            payload: {}
        }
    } else {
        let modelResultFromEquipment = await adminModel.getEquipmentOnLoanMsgFromEquipment(equipmentID);
        let modelResultFromApply = await adminModel.getEquipmentOnLoanMsgFromApply(equipmentID);

        let { equipmentName, equipmentPicture, isCamera } = modelResultFromEquipment;
        let { stuID, startTime, returnTime, contactInfo } = modelResultFromApply;
        let stuIdArray = [stuID];
        let ssoRes = await sso.getUserByStuID(stuIdArray);
        //console.log(stuID);
        //console.log(ssoRes);
        let name = ssoRes[stuID].realName;
        //console.log(ssoRes[stuID]);
        //console.log(name);
        //let name = await adminModel.getName(stuID);
        let modelResult = modelResultFromEquipment;
        modelResult.name = name;
        Object.assign(modelResult, modelResultFromApply);

        if (!name) {
            ret = {
                errorCode: 400,
                errorMsg: "user数据库错误",
                payload: {}
            }
        } else {
            ret = {
                errorCode: 200,
                errorMsg: "成功返回该借出设备信息",
                payload: modelResult
            }
        }

    }

    return ret;
}