const models = require("../model/index");
const sso = require("./ssoUtil.js");
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'; // 暂时解决证书过期问题

exports.tokenChecker = async (accesstoken) => {
    //console.log(accesstoken);
    let flag = 1;
    let result = await sso.getUserInformation(accesstoken).then().catch(function (err) {
        flag = 0;
        return {
            errorCode: 401,
            errorMsg: err,
            payload: {}
        };
    });

    if(flag) {
        return {
            errorCode: 200,
            errorMsg: "accesstoken正确",
            payload: result
        };
    } else {
        return result;
    }
}

exports.putBorrowApply = async (stuID, contactInfo, body, params) => {
    let ret;
    let equipmentID = params.equipmentID;
    let startTime = body.startTime;
    let reason = body.reason;
    let returnTime = body.returnTime;
    let modelResult = await models.userModel.putBorrowApply(
        equipmentID,
        startTime,
        reason,
        contactInfo,
        returnTime,
        stuID,
    );

    if (modelResult) {
        ret = {
            errorCode: 200,
            errorMsg: "借用成功",
            payload: {}
        };
    } else {
        ret = {
            errorCode: 400,
            errorMsg: "操作数据库出错",
            payload: {}
        };
    }
    return ret;
};

exports.getUserInfo = async (body, params, userInfo) => {
    let ret;

    let stuID = userInfo.id;
    //console.log(userInfo);
    //console.log(stuID);
    let userResult = await models.userModel.getUserInfo(stuID);

    if (userResult) {
        userResult.stuID = stuID;
        userResult.name = userInfo.realName;
        userResult.contactInfo = userInfo.phone;
        userResult.department = userInfo.positions[0].departmentId;
        userResult.position = userInfo.positions[0].postName;
        userResult.stuPicture = userInfo.avatar;
        ret = {
            errorCode: 200,
            errorMsg: "成功返回个人基本信息",
            payload: userResult
        };
    } else {
        ret = {
            errorCode: 400,
            errorMsg: "操作数据库出错，获取信息失败",
            payload: {}
        };
    }
    return ret;
};

exports.getBorrowedEquipment = async (body, params, userInfo) => {
    let ret;

    let stuID = userInfo.id;
    let borrowedEquipment = await models.userModel.getBorrowedEquipment(stuID);
    //console.log(borrowedEquipment);
    if (!borrowedEquipment) {
        ret = {
            errorCode: 402,
            errorMsg: "个人没有借用设备",
            payload: {}
        };
    } else {
        ret = {
            errorCode: 200,
            errorMsg: "查询被借用设备信息成功",
            payload: {
                data: borrowedEquipment
            }
        };
    }

    return ret;
};

exports.putEquipmentRet = async (body, params, userInfo) => {
    let ret;
    let equipmentID = params.equipmentID;

    let stuID = userInfo.id;

    let equipmentBorrowed = await models.userModel.getBorrowedEquipment(stuID);

    let flag = 0;
    if(equipmentBorrowed) {
        for(let i = 0; i < equipmentBorrowed.length; i++) {
            if(equipmentBorrowed[i].equipmentID == equipmentID) flag = 1;
        }
    }

    if(flag == 0) {
        ret = {
            errorCode: 402,
            errorMsg: "归还设备不存在于被借出设备，归还失败",
            payload: {}
        }
    } else {
        let modelResult = await models.userModel.putEquipmentRet(equipmentID, stuID);
        if (!modelResult) {
            ret = {
                errorCode: 400,
                errorMsg: "操作数据库出错，归还失败",
                payload: {}
            };
        } else {
            ret = {
                errorCode: 200,
                errorMsg: "成功归还设备",
                payload: {}
            };
        }
    }    
    return ret;
};

exports.getEquipmentInfo = async (params) => {
    let isCamera = params.isCamera;
    let size = params.size;
    let page = params.page;
    let needStatus = params.needStatus;
    //console.log(needStatus);
    let data =[];
    let modelResult;
    if(needStatus == 0)  {//前端希望传过去所有的设备
        modelResult = await models.userModel.getEquipmentInfoAll(isCamera);
    } else if(needStatus == 1)  {//前端希望只传已借出的设备
        modelResult = await models.userModel.getEquipmentInfoIfBorrowed(isCamera, 1);
    } else  {//前端希望只传未被借出的设备
        modelResult = await models.userModel.getEquipmentInfoIfBorrowed(isCamera, 0);
    }
    
    if(!modelResult){
        ret = {
            errorCode: 402,
            errorMsg: "数据库无所需数据",
            payload:{},
        };
    } else {
        let totalNum = modelResult.totalNum;
        let equipmentRet = modelResult.data;
        //console.log(totalNum,equipmentRet);
        let start = (page - 1) * size;
        let end = Math.min(start + parseInt(size), totalNum);
        //console.log(start,end,start + size);
        for (let i = start; i < end; i++){
            data.push(equipmentRet[i]);
        }
        // console.log(data == false);
        if (data == false && totalNum != 0) {
            ret = {
                errorCode: 403,
                errorMsg: "page 参数出错",
                payload: {}
            };
        } else {
            ret = {
                errorCode: 200,
                errorMsg: "成功返回设备信息",
                payload: {
                    totalNum: totalNum,
                    data: data
                }
            };
        }   
    }
    return ret;
}
