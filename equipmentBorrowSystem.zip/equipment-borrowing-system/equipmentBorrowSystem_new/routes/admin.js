var express = require('express');
var router = express.Router();
const controller = require("../controller/index")
const { adminController } = controller;

router.use("/", async (req, res, next) => {
    let ret = await adminController.tokenChecker(req.headers['access-token']);

    if (ret.errorCode == 200) {
        req.userInfo = ret.payload;

        let stuID = req.userInfo.id;
        let result = await adminController.isAdmin(stuID);
      console.log(stuID);
      console.log(result);
        if(!result) {
            let message = {
                errorCode: 201,
                errorMsg: "不是管理员呀",
                payload: {}
            }
            res.send(message).end();
        } else {
            next();
        }
    } else {
        let message = {
            errorCode: 401,
            errorMsg: "用户信息已过期",
            payload: {}
        }
        res.send(message).end();
    }
})

//007
router.post("/equipmentAdd", async (req, res) => {
    let ret = await adminController.putEquipmentAdd(req.body, req.params);
    res.send(ret).end();
})

//008
router.delete("/equipmentID/:equipmentID/equipmentDelete", async (req, res) => {
    let ret = await adminController.deleteEquipmentDelete(req.body, req.params);
    res.send(ret).end();
})

//009
router.get("/size/:size/page/:page/equipmentOnLoan", async (req, res) => {
    let ret = await adminController.getEquipmentOnLoan(req.params);
    res.send(ret).end();
})

//010
router.get("/equipmentID/:equipmentID/equipmentOnLoanMsg", async (req, res) => {
    let ret = await adminController.getEquipmentOnLoanMsg(req.params);
    res.send(ret).end();
})

module.exports = router;